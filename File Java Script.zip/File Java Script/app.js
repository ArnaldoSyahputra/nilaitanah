  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyDhmspkmgaeJNHUA-TEoiecq87fa2lIGz8",
    authDomain: "belajar-chart.firebaseapp.com",
    databaseURL: "https://belajar-chart.firebaseio.com",
    projectId: "belajar-chart",
    storageBucket: "",
    messagingSenderId: "439225952232"
  };
  firebase.initializeApp(config);